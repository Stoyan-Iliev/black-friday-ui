import MainNavBar from "./MainNavBar";

import { getAllProducts } from "../api/backendRequests";
import { useEffect, useState } from "react";
import { filter } from "../utils/constants";
import ProductList from "./ProductList";

export default function Home() {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState(new Map());
  const allProducts = () => {
    getAllProducts()
      .then((response) => {
        console.log(response.data);
        setProducts(response.data);
        setFilteredProducts(filter(response.data));
      })
      .catch((error) => {
        console.log(error);
      });
  };

  useEffect(() => {
    allProducts();
  });

  console.log(products);
  console.log(filteredProducts);

  // let filteredProducts = filter(products);

  return (
    <div>
      <MainNavBar />
      <ProductList products={products} type="Laptops" />
      {/* {filteredProducts.entries.map((key, value) => (
        <ProductList products={value} type={key} />
      ))} */}
    </div>
  );
}
