import DynamicProductList from "./product/DynamicProductList";

export default function CampaignChoice() {
  let { id } = useParams();
  const [products, setProducts] = useState([]);
  const allProducts = () => {
    getAllProducts()
      .then((response) => {
        console.log(response.data);
        setProducts(response.data);
      })
      .catch((error) => console.log(error));
  };

  useEffect(() => {
    allProducts();
  }, []);

  return (
    <>
      <MainNavBar />
      <DynamicProductList products={products} />
      {/* <AppFooter /> */}
    </>
  );
}
