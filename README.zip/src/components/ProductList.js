import { Grid } from "@mui/material";
import ProductPreview from "./ProductPreview";

export default function ProductList({ products, type }) {
  return (
    <div>
      <h2 style={{ textAlign: "left", padding: "5px" }}>{type}</h2>
      <Grid container direction="row">
        {products.map((p, index) => (
          <ProductPreview product={p} key={index} />
        ))}
      </Grid>
    </div>
  );
}
